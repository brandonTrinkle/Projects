// Student Name: Brandon Trinkle
// Student ID: 1217455031
// Date: 1/17/2025

console.log("Hello, World!")